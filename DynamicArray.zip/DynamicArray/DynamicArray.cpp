#include <iostream>
using namespace std;

template <typename T>
class Arreglo
{
private:
    T* datos;
    int tam;
    int capacidad;

public:
    Arreglo()
    {
        capacidad = 10;
        tam = 0;
        datos = new T[capacidad];
    }

    ~Arreglo()
    {
        delete[] datos;
    }

    void push_back(T valor)
    {
        if (tam == capacidad)
        {
            capacidad = capacidad * 2;
            T* nuevo = new T[capacidad];

            for (int i = 0; i < tam; i++)
            {
                nuevo[i] = datos[i];
            }

            delete[] datos;
            datos = nuevo;
        }

        datos[tam] = valor;
        tam++;
    }

    void pop_back()
    {
        if (tam > 0) { tam--; }
    }

    void shrink_to_fit()
    {
        if (capacidad > tam)
        {
            T* nuevo = new T[tam];

            for (int i = 0; i < tam; i++)
            {
                nuevo[i] = datos[i];
            }

            delete[] datos;
            datos = nuevo;
            capacidad = tam;
        }
    }//

    T& operator[](int i)
    {
        return datos[i];
    }

    int ObtenerTam()
    {
        return tam;
    }
};

int main()
{

    Arreglo<int> numeros;

    numeros.push_back(8);
    numeros.push_back(16);
    numeros.push_back(24);

    numeros.pop_back();
    numeros.pop_back();

    return 0;
}